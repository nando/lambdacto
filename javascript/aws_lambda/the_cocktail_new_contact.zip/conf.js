/* Copyright 2016 The Cocktail Experience, S.L. */
module.exports = {
  domains: {
    'the-cocktail.com': {
      emailAddress: "The Cocktail Site <fernando.garcia@the-cocktail.com>",
      emailSubject: "New contact in The Cocktail Website"
    },
    'thecocktailventures.com': {
      emailAddress: "TckVentures Website <ventures@the-cocktail.com>",
      emailSubject: "New contact with The Cocktail Ventures"
    }
  }
}
